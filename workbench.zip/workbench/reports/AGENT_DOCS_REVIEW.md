# Plains — Revisione e consolidamento della documentazione per agenti (AGENT-DOC-003)

> Compito: documentazione-only. Nessuna modifica a codice applicativo, test,
> dipendenze, schema o dati persistenti.
>
> Baseline: branch `matteo/development`, commit `5e312860fa00bb84180cbe34ecb1df80f5291012`.

---

## 1. Inventario della documentazione per agenti

| Percorso | Ruolo | Stato |
|----------|-------|-------|
| `CLAUDE.md` (root, ~330 righe / 18,7 KB) | **Unica** istruzione di contesto sempre caricata (Pi e Claude Code). | Attivo. Corretto in 4 punti (vedi §3). |
| `.github/agents/playwright-test-generator.agent.md` | Agente Copilot: generazione test Playwright. | Lasciato invariato (specifico Copilot). |
| `.github/agents/playwright-test-planner.agent.md` | Agente Copilot: piano di test. | Lasciato invariato. |
| `.github/agents/playwright-test-healer.agent.md` | Agente Copilot: debug/riparazione test. | Lasciato invariato. |
| `CONTRIBUTING.md` | Linee guida contributori (template FastAPI). | Obsoleto: linka `development.md` inesistente. Non è documentazione per agenti: lasciato invariato, segnalato. |
| `README.md`, `backend/README.md`, `frontend/README.md` | Template FastAPI con riferimenti a `development.md` inesistente. | Segnalati, non modificati. |
| `tasks/status.md` + `tasks/task*.md` | Storico task di un altro branch (`claude/keen-dijkstra-7n118n`). | Contesto storico, non stato corrente. |
| `docs/plans/*`, `docs/nomad-upload-debugging.md` | Piani di design e debugging. | Utili, preservati. |
| `DEPLOY_SECURITY_CHECKLIST.md`, `SECURITY.md` | Check-list sicurezza/rilascio. | Preservati. |

**Assenti**: `AGENTS.md`, `.pi/`, `.agents/`, `CLAUDE.md`/`AGENTS.md` annidati. Non ne è
stato creato nessuno (vedi §5).

### Come Pi carica le istruzioni (verificato)

Dalla documentazione Pi (`/opt/pi-coding-agent/docs/configuration.md`):
- i *context file* vengono caricati dalla directory dell'agente, dalla working directory e
  dalle directory genitrici;
- entro una singola directory vale **uno slot** per `AGENTS.override.md` > `AGENTS.md` >
  `AGENTS.MD` > `CLAUDE.md` > `CLAUDE.MD`; `AGENTS.override.md` sostituisce `AGENTS.md` **o**
  `CLAUDE.md` nella stessa directory;
- il discovery **non** richiede project trust.

**Verifica empirica** (ambiente `/tmp/pitest` con `AGENTS.md` e `CLAUDE.md` entrambi
presenti): il session file registra **solo** il contenuto di `AGENTS.md` e nessun contenuto
di `CLAUDE.md`. ⇒ **Creare un `AGENTS.md` alla root farebbe smettere a Pi di caricare
`CLAUDE.md`.**

---

## 2. Problemi rilevati

### In `CLAUDE.md` (corretti)

1. **[PERICOLOSO/OUTDATED]** Sezione "Database Migrations" indicava
   `alembic revision --autogenerate` / `alembic upgrade head`. Contrario alla realtà:
   `scripts/prestart.sh` non esegue Alembic; lo schema è gestito da
   `init_db()` (`create_all` + `ALTER TABLE … ADD COLUMN IF NOT EXISTS`); la history Alembic è
   già **divergente** (manca `step_ref`, le colonne trash, la tabella `trash_entry`).
   Un agente che seguisse l'istruzione eseguirebbe `alembic upgrade head` su un deployment
   reale senza applicare lo schema completo e rischiando conflitti.
2. **[INACCURATO]** "State: `AppContext.tsx` … holding all application data (materials,
   solutions, experiments, results, planes)": `AppContext` **non** mantiene
   materiali/soluzioni (nessuno `useState` per essi; le pagine Materiali/Soluzioni ritornano
   `null`). Lo snapshot contiene experiments, processes, results, planes, folders.
3. **[INACCURATO]** Routing: `_gui/` elencava "materials, solutions" fra le route, che non
   esistono (le route `_gui` reali sono organization, processes, experiments, results,
   analysis, export, trash).
4. **[INCOMPLETO/IMPRECISO]** Data Model: elencava `Material`/`Solution` come entità chiave
   senza chiarire che sono tabelle di inventario alimentate a export NOMAD (non entità CRUD
   della GUI) e ometteva `Process`, `TrashEntry` e gli elementi canvas.

### Altrove (segnalati, non modificati)

5. `CONTRIBUTING.md` e `backend/README.md` linkano `development.md`, che non esiste (residuo
   del template "Full Stack FastAPI Template").
6. `tasks/status.md` appartiene a un altro branch: va letto come storico, non come stato
   corrente.
7. File non tracciati spuri alla root: `Copia di workbench/` e `workbench.zip` (artefatti di
   una sessione precedente) sporcano `git status`. Non rimossi (fuori scope e non miei da
   toccare).
8. Il percorso preesistente `/home/simon/plains` in `CLAUDE.md` (sezione `git stash`) espone
   un nome utente di un contributore. Preesistente, lasciato; da valutare a parte.

---

## 3. File modificati e motivazioni

Solo **`CLAUDE.md`** (1 file tracciato, 21 righe aggiunte / 12 rimosse):

1. **"Database Migrations" → "Database schema (created at startup — not via Alembic)"**:
   descrive il meccanismo reale (`create_all` + DDL ad hoc in `init_db`) e mette in guardia
   dal non eseguire `alembic upgrade head`/`--autogenerate` senza riconciliare la history.
2. **"State"**: corretto l'elenco dello snapshot e aggiunto il chiarimento che
   materiali/soluzioni sono tabelle backend materializzate a export NOMAD.
3. **"Routing"**: elenco route `_gui` corretto (via `materials`/`solutions`, aggiunto `trash`).
4. **"Data Model"**: aggiunto `Process`, `TrashEntry`, elementi canvas; chiarito il ruolo di
   `LabMaterial`/`LabSolution`.
5. **"Non-regression policy" (nuova sezione)**: esplicitati i 10 principi di non-regressione,
   il quadro "what/why/impact/verification/uncertain" e la regola sui bug-fix scientifici
   autorizzati. Prima erano solo impliciti e sparsi.

Nessuna modifica a `CONTRIBUTING.md`, `README*`, `.github/agents/*` (fuori scope o specifici
di un agente).

---

## 4. Istruzioni importanti preservate (non toccate)

- Protezione del database di sviluppo: `docker compose down -v`, `scripts/db-backup.sh` /
  `db-restore.sh`, divieto di `pytest` diretto sullo stack dev, database isolato `app_test`.
- Regole `git stash` (mai pop alla cieca, verifica `pwd`/pathspec, `tail -N` nei pipe).
- Comandi backend/frontend verificati esistenti e corretti (incluso `docker compose watch`,
  confermato da `compose.override.yml` `develop.watch`).
- Architettura backend/frontend, alias `@/`, client generato, guardia `vite:preloadError`.
- Versioning schema PDF (`PDF_SCHEMA_VERSION` + ladder migrazioni).
- Sezione React/Mantine Strict Mode (ref inline, loop effetto↔effetto, "Maximum update depth"
  #185, patch `@mantine/core@7.17.8`, errori backend mascherati da CORS, FK rimossa su
  `lab_substrate.substrate_material_id`).
- Integrazione NOMAD e credenziali fuori repo (`../sensitive config/.nomad_auth`).
- URL di sviluppo.

---

## 5. Compatibilità fra agenti

- **Pi**: carica `CLAUDE.md` (unico file presente). Se in futuro si aggiungesse `AGENTS.md`
  alla root, `AGENTS.md` **sostituirebbe** `CLAUDE.md` per Pi (verificato empiricamente) — da
  non fare senza migrare il contenuto.
- **Claude Code**: carica `CLAUDE.md` (convenzione nativa). Nessun impatto dalle modifiche.
- **Codex**: legge `AGENTS.md`, **non** `CLAUDE.md`. Oggi Codex non riceve istruzioni di
  progetto. È una **limitazione residua documentata**, non risolta per non rompere Pi.

**Decisione registrata (non ancora eseguita come codice):** mantenere `CLAUDE.md` come unica
fonte condivisa e **non** creare un `AGENTS.md` alla root, perché ciò fermerebbe il caricamento
delle istruzioni critiche da parte di Pi. Se Codex diventasse un requisito reale, la
migrazione andrebbe fatta con cautela: spostare il contenuto condiviso in `AGENTS.md`,
ridurre `CLAUDE.md` a puntatore, e verificare il comportamento di ogni tool (la precedenza
Pi è già nota; il supporto di `AGENTS.md` da parte della versione di Claude Code in uso va
confermato prima).

---

## 6. Skill valutate — decisione: nessuna

Aree candidate valutate e perché **non** è stata creata alcuna skill:

- **Verifica di regressione sicura**: le istruzioni necessarie (test isolati, `scripts/test.sh`
  con backup/restore, database `app_test`, suite seriali per i loop) sono già in `CLAUDE.md`;
  una skill aggiungerebbe solo ridondanza.
- **Protezione database/persistenza**: coperta da `CLAUDE.md` e dagli skill globali già
  installati (es. `docker-destructive-guardrails`). Nessun valore aggiunto specifico.
- **Dati scientifici / validazione export NOMAD**: conoscenza già in `docs/plans/*` e
  `services/nomad.py`; un workflow riusabile non è emerso come *non banale* e *ricorrente*
  oltre quanto già documentato.

**Esito**: zero nuove skill (criterio: una skill serve solo se aggiunge un workflow
riusabile e non banale non già coperto dalle istruzioni di progetto).

---

## 7. Limitazioni residue

- Il supporto di `AGENTS.md` da parte della specifica versione di Claude Code in uso non è
  stato verificato (non c'è un Claude Code installato/richiamabile in questo ambiente):
  per questo non è stato introdotto `AGENTS.md`.
- `CONTRIBUTING.md`/`README*` con link rotto `development.md` non sono stati corretti (fuori
  scope "istruzioni per agenti"; richiederebbero una decisione del maintainer).
- La verifica del caricamento Pi è stata fatta con una singola invocazione in una directory
  temporanea (modello configurato, prompt banale); il comportamento è comunque coerente con
  la documentazione ufficiale Pi.
- `frontend/.env` (tracciato) non è stato letto né citato nel contenuto.

---

## 8. File modificati (riepilogo esatto)

- `CLAUDE.md` — 5 modifiche: 4 correzioni (schema DB, State, Routing, Data Model) +
  nuova sezione "Non-regression policy". Unico file tracciato modificato.
- `workbench/reports/AGENT_DOCS_REVIEW.md` — questo report (nuovo).
- `workbench/STATUS.md`, `workbench/TODO.md` — aggiornati.

Nessun file applicativo, test, dipendenza, schema o dato persistente modificato. Nessuna
skill creata. Nessun `AGENTS.md` creato.
