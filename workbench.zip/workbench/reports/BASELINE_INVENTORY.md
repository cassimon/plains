# Plains — Inventario di baseline (FOUNDATION-01)

> Scopo: consolidare la conoscenza tecnica verificata del repository per rendere più
> sicure le modifiche future. **Non** afferma che Plains sia già "regression-safe".
>
> Baseline: branch `matteo/development`, commit `5e312860fa00bb84180cbe34ecb1df80f5291012`.
> Riferimenti: `INITIAL_AUDIT.md` (architettura), `AUDIT_VERIFICATION.md` (persistenza,
> migrazioni, scientifico), `AGENT_DOCS_REVIEW.md` (documentazione agenti).
>
> Documento di sola analisi: nessuna modifica a codice/dipendenze/schema.

---

## 1. Mappa di framework e librerie consolidate

### Backend (workspace `uv`: root `pyproject.toml` → `backend/`, lockfile `uv.lock` alla root)

| Libreria | Versione dichiarata | Responsabilità attuale |
|----------|---------------------|------------------------|
| FastAPI (standard) | `>=0.114.2,<1.0.0` | App HTTP, router, OpenAPI (`app/main.py`, `api/routes/`). |
| SQLModel (SQLAlchemy) | `>=0.0.21,<1.0.0` | Modelli/tabelle + schemi Pydantic in `app/models.py`. |
| psycopg (binary) | `>=3.1.13,<4.0.0` | Driver PostgreSQL. |
| Pydantic / pydantic-settings | `>2.0` / `>=2.2.1` | Validazione e configurazione da `.env` (`core/config.py`). |
| Alembic | `>=1.12.1,<2.0.0` | Presente ma **non eseguito** in `prestart.sh`; history divergente (vedi §4). |
| slowapi | `>=0.1.10` | Rate limiting login (`core/limiter.py`). |
| PyJWT | `>=2.8.0,<3.0.0` | JWT locale HS256; verifica NOMAD RS256 via JWKS (`core/security.py`). |
| pwdlib[argon2,bcrypt] | `>=0.3.0` | Hash password. |
| sentry-sdk[fastapi] | `>=2.0.0,<3.0.0` | Monitoraggio errori. |
| httpx / tenacity | `>=0.25.1` / `>=8.2.3` | Client HTTP NOMAD; retry attesa DB. |
| emails + jinja2 | `>=0.6` / `>=3.1.4` | Email (template MJML). |
| pyyaml / cryptography | `>=6.0` / `>=39.0.0` | YAML metadata NOMAD; crypto. |
| pytest / mypy / ruff / coverage / ty / prek (dev) | pytest `<8`, mypy `strict`, ruff target `py310`, coverage `fail_under=80` | Test, type-check, lint. |

### Frontend (workspace `bun`: root `package.json` → `frontend/`; lockfile `bun.lock` alla root)

| Libreria | Versione dichiarata | Responsabilità attuale |
|----------|---------------------|------------------------|
| React / React DOM | `^19.2.7` | UI (React 19, Strict Mode attivo in dev). |
| Vite / TypeScript | `^7.3.5` / `^5.9.3` | Build/dev (`vite.config.ts`). |
| TanStack Router / Query / Table | `^1.170` / `^5.101` / `^8.21` | Routing file-based; cache/query; tabelle (`Common/DataTable.tsx`). |
| Mantine core + hooks/modals/notifications/dropzone | `^7.17.8` (**patching** `@mantine/core@7.17.8`) | Modali, notifiche, dropzone, primitivi fluttuanti. |
| shadcn/ui (Radix) | `@radix-ui/*` vari | Componenti base in `components/ui/`. |
| Tailwind CSS v4 | `^4.3.1` | Stile. |
| ECharts + echarts-for-react | `^6.1.0` / `^3.0.6` | Grafici (`Analysis.page.tsx`). |
| pdf-lib | `^1.17.1` | Export/import PDF AcroForm (`lib/pdfSchema.ts`, `lib/processExport.ts`, `lib/pdfImport.ts`). |
| keycloak-js | `^26.2.4` | SSO (`lib/keycloakInstance.ts`). |
| axios | `^1.18.1` | Client OpenAPI generato (`src/client/`). |
| zod / react-hook-form / @hookform/resolvers | `^4.4.3` / `^7.80` / `^5.4` | Validazione + form. |
| sonner / next-themes | `^2.0.7` / `^0.4.6` | Toast; tema. |
| Icone: lucide-react / @tabler/icons-react / react-icons | `^0.563` / `^3.44` / `^5.6` | **Tre** set di icone coesistenti. |
| @hey-api/openapi-ts / Biome / Playwright (dev) | `0.73.0` / `^2.5.1` / `1.56.1` | Generazione client; lint; E2E. |

**Note sui lockfile**: coesistono `bun.lock` (root), `package-lock.json` (root) e
`frontend/package-lock.json`. Il comando documentato è `bun`; i lockfile npm sono residui
di un doppio gestore pacchetti. `uv.lock` è alla root (workspace uv verso `backend/`).
Il nome del root `package.json` è ancora `"fastapi-full-stack-template"` (residuo del
template).

---

## 2. Soluzioni custom che potrebbero duplicare funzionalità di libreria

| Soluzione custom | Libreria già presente | Valutazione |
|------------------|----------------------|-------------|
| `store/backend.ts` `HttpBackend` (fetch raw + upsert/delete-reconciliation) | Client OpenAPI generato (axios) | **Duplicazione** del livello HTTP: due meccanismi di rete. Da consolidare (vedi §7). |
| `components/ui/*` (shadcn/Radix) accanto a Mantine | Mantine core | **Sovrapposizione** di primitive UI (modali, dropdown, tooltip). Coesistono intenzionalmente ma aumentano la superficie. |
| Tre set di icone (lucide, tabler, react-icons) | — | **Duplicazione** di dipendenze equivalenti; `react-icons` usato in 1 solo file. |
| `Common/DataTable.tsx` | `@tanstack/react-table` | **Non è duplicazione**: è un wrapper corretto su TanStack Table. |
| `lib/solutionConcentration.ts`, `stockSolutions.ts`, `stackDivergence.ts`, `processingTimes.ts`, `pdfSchema.ts`, `gridPacking.ts` | — | **Non duplicazione**: matematica scientifica/dominio e codec PDF AcroForm senza equivalente di libreria. Da preservare. |

---

## 3. Decisioni di progetto storiche e loro validità attuale

| Decisione | Dove | Validità attuale |
|-----------|------|------------------|
| UUID client-generated (`ClientIdCreate`) | `models.py` | **Valida**: rende possibile il round-trip dei riferimenti incrociati del frontend. |
| Persistenza "snapshot intero" + riconciliazione create/update/delete | `backend.ts` `syncToBackend()` | **Valida per singola sessione**; limite noto last-writer-wins su sessioni concorrenti. |
| Soft-delete (Trash) + restore con ri-attacco posizionamento server-side | `services/trash.py` | **Valida**; delete verso il basso, restore verso l'alto. |
| Schema via `create_all` + DDL ad hoc (`init_db`) invece di Alembic in `prestart` | `core/db.py`, `scripts/prestart.sh` | **Funziona oggi** ma fragile; history Alembic divergente (vedi §4). |
| Materiali/Soluzioni materializzati a export NOMAD (`chemicals_materialization`) | `services/chemicals_materialization.py` | **Valida**; le tabelle `lab_material`/`lab_solution` sono inventario, non entità CRUD della GUI. |
| PDF AcroForm con schema versionato + ladder di migrazione | `lib/pdfSchema.ts` | **Valida**; `PDF_SCHEMA_VERSION = 5`. |
| Guardia `vite:preloadError` (chunk stantii) | `main.tsx` | **Valida**; da mantenere. |
| Patch `@mantine/core@7.17.8` (ScrollArea ref stabilizzati) | `patches/` | **Valida**; da verificare/rimuovere solo a un bump Mantine. |
| FK rimossa su `lab_substrate.substrate_material_id` | `init_db()` | **Valida** (id inline-substrate, non `lab_material`); non ri-aggiungere. |
| FF in frazione / PCE in percentuale nell'export NOMAD | `services/nomad.py` `_fill_factor_fraction` | **QUESTION** (asimmetria non risolta; da verificare con lo schema NOMAD). |

---

## 4. Vincoli di compatibilità e workaround noti

- **Patch Mantine**: `patches/@mantine%2Fcore@7.17.8.patch` stabilizza i ref interni di
  ScrollArea. Un bump di Mantine può invalidarla (verificare prima).
- **Guardia chunk stantii**: `main.tsx` ricarica una sola volta (cap 1 reload/10 s) su
  `vite:preloadError`. Da mantenere quando si tocca `main.tsx`.
- **Errori 500 mascherati da CORS**: un'eccezione non gestita risponde senza header CORS;
  il browser la vede come `TypeError: Failed to fetch`. Cercare il 500 in
  `docker compose logs backend`, non nella config CORS. Registrare handler per tipi
  specifici di eccezione (non `Exception`).
- **FK `lab_substrate.substrate_material_id` rimossa** in `init_db` (DROP CONSTRAINT).
  Storicamente causa di `IntegrityError` → 500 mascherato. Non ri-aggiungere.
- **Schema DB**: `create_all` non altera tabelle esistenti; le colonne aggiunte dopo il
  primo rilascio sono applicate dai `ALTER TABLE … ADD COLUMN IF NOT EXISTS` in `init_db`.
  La history Alembic è **divergente** (manca `step_ref`, le colonne trash, la tabella
  `trash_entry`): non eseguire `alembic upgrade head`/`--autogenerate` senza riconciliazione.
- **Overrides/security frontend**: `form-data >=4.0.6` (CVE), `rollup`, `postcss`,
  `picomatch` pin (root `package.json` overrides).
- **Backend**: `mypy strict`, `ruff` target `py310`, `coverage fail_under=80`; `ruff`
  esclude `alembic`.
- **React 19 + Mantine 7**: Strict Mode (dev) + hook Mantine ⇒ regole anti-loop (ref
  stabilizzati, sync unidirezionale) documentate in `CLAUDE.md`.

---

## 5. Invarianti comportamentali critici per futuri refactor

- **Risultati incompleti mai persistiti**: `persistableResults` esclude i risultati con
  file ma senza `nomad.upload_id` da ogni snapshot salvato.
- **Upload completati mai cestinati**: `is_finished_upload()` (status `SUCCESS`) esclude
  dal trash.
- **Versioning PDF**: ogni cambio di forma serializzata ⇒ bump `PDF_SCHEMA_VERSION` +
  entry nella ladder; mai riusare un numero di versione.
- **Sync stato unidirezionale**: mai due effect che scrivono lo stesso stato osservandosi
  a vicenda (regola anti-loop React; vedi `CLAUDE.md`).
- **Piani**: mai eliminare l'ultimo piano; cancellare una cartella "sgruppa" i piani
  (non li cancella).
- **Materializzazione chemicals idempotente** su `(owner_id, inventory_label)`.
- **Cascate**: delete verso il basso (process → experiment → result); restore verso l'alto.
- **PK UUID, cascate ondelete, colonna `frontend_data` JSONB** su ogni tabella entità.
- **Ordine FK nella riconciliazione**: folders → planes → processes → experiments →
  results; deletions in ordine inverso.

---

## 6. Protezioni di regressione mancanti (le più importanti)

1. **Nessun test per `soluteVolumeMl` unità `mol`** — off-by-1000 confermato
   (`solutionConcentration.ts`); tutti i fixture `mol` omettono `density`.
2. **Nessun test che fissi le unità FF/PCE nell'export NOMAD** — `default_FF` in frazione,
   `default_PCE` in percentuale (asimmetria non verificata).
3. **Nessun retry/ripristino dirty su salvataggio fallito** — finestra di perdita del
   singolo edit (errore rete + chiusura scheda).
4. **Nessun test di concorrenza multi-sessione** — i test di integrazione girano seriali
   per costruzione.
5. **Nessun test di migrazione/schema** per `create_all` + DDL ad hoc su database
   esistenti.
6. **Suite backend non eseguibile senza Docker/Postgres** (e `down -v` sul DB dev è
   distruttivo): copertura CI limitata per i test di route/servizi.

---

## 7. Opportunità di modernizzazione (separate dalle modifiche approvate)

*Nessuna è approvata né in corso; FOUNDATION-01 non modifica manifest/lockfile.*

- **Consolidare il livello HTTP** (client OpenAPI generato vs `fetch` in `HttpBackend`).
- **Consolidare i set di icone** (3 → 1; `react-icons` usato in 1 file).
- **Riconciliare i lockfile** (`bun.lock` vs `package-lock.json`) e il nome template del
  root `package.json`.
- **Decidere sulla coesistenza Mantine/shadcn** (deliberazione, non pulizia meccanica).
- **Riconciliare/ripristinare Alembic** (decisione esplicita, non automatica).
- **Aggiornamenti mirati** (es. Mantine 8, eventuali EOL) solo con verifica di
  compatibilità e copertura di regressione; mai come effetto collaterale di altro lavoro.

---

### Chiusura

FOUNDATION-01 **crea le condizioni** per modifiche future più sicure. **Non afferma** che
Plains sia già regression-safe: i punti §6 restano scoperti e vanno colmati prima di
refactor che toccano quei comportamenti.
