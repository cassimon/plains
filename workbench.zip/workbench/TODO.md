# TODO

Legenda: **[PROPOSTO]** = suggerito, non ancora approvato · **[APPROVATO]** = autorizzato ·
**[FATTO]** = completato (verificabile).

## Documentazione agenti (AGENT-DOC-003)

- [FATTO] Verificare il comportamento di caricamento Pi (AGENTS.md vs CLAUDE.md).
- [FATTO] Correggere `CLAUDE.md`: schema DB, State, Routing, Data Model.
- [PROPOSTO] Migrare ad `AGENTS.md` **solo se** Codex diventa un requisito: spostare il
  contenuto condiviso in `AGENTS.md`, ridurre `CLAUDE.md` a puntatore, verificare il supporto
  `AGENTS.md` della versione di Claude Code in uso. *Non fare alla cieca: AGENTS.md
  sostituisce CLAUDE.md per Pi.*
- [PROPOSTO] Far correggere al maintainer i link rotti `development.md` in
  `CONTRIBUTING.md`/`README*` (residui del template).
- [PROPOSTO] Rimuovere/ignorare gli artefatti spuri alla root (`Copia di workbench/`,
  `workbench.zip`) previa conferma del proprietario.

## Priorità alta (tecnica)

1. [PROPOSTO] **Verificare le unità di FF/PCE contro lo schema NOMAD**
   (`perovskite_solar_cell_database`): `default_FF` in frazione, `default_PCE` in
   percentuale (`services/nomad.py`). Se PCE è frazione, efficienza 100× errata.
2. [PROPOSTO] **Correggere `soluteVolumeMl` per unità `mol`**
   (`frontend/src/lib/solutionConcentration.ts`): rimuovere il `/1000` spurio
   (`(amt * molarMass) / density`) + test con `mol` + `density`.
3. [PROPOSTO] **Decidere la strategia migrazioni**: ripristino Alembic previa
   riconciliazione della history divergente, oppure formalizzazione dei DDL di `init_db`.
   Non riabilitare Alembic alla cieca.

## Priorità media

4. [PROPOSTO] **Ripristino del dirty-state su salvataggio fallito** (e/o retry) in
   `persistDirtyState`/`HttpBackend.save` (perdita del singolo edit su errore + chiusura).
5. [PROPOSTO] **Verificare `frontend/.env`** (con chi ha accesso): se contiene segreti,
   rimuoverlo dall'indice Git. *Non leggere il file.*

## Priorità bassa (opzionale)

6. [PROPOSTO] Rimuovere il **solo** codice UI morto Materiali/Soluzioni (pagine,
   `newMaterial`/`newSolution`, import type-only); **non** toccare tabelle backend né
   `chemicals_materialization`.
7. [PROPOSTO] Consolidare i due client HTTP (client OpenAPI generato + `fetch` in
   `HttpBackend`).
8. [PROPOSTO] Estrarre gradualmente i componenti pagina monolitici, senza cambiare
   comportamento.

## Non trasformare in task

- Osservazioni minori e preferenze stilistiche; nessun refactoring ampio senza evidenza.
