# Status

> Ultimo aggiornamento: inventario di baseline (FOUNDATION-01) completato.

## Baseline

- Repository: **Plains** (`cassimon/plains`).
- Branch: **`matteo/development`**, working tree con modifiche **solo documentazione**.
- Commit base: **`5e312860fa00bb84180cbe34ecb1df80f5291012`** (2026-07-22).
- `workbench/` escluso via `.git/info/exclude`.

## Analisi completate

1. **Audit architetturale iniziale** → `reports/INITIAL_AUDIT.md`.
2. **Verifica e prioritizzazione** → `reports/AUDIT_VERIFICATION.md`.
3. **Revisione/consolidamento documentazione agenti** → `reports/AGENT_DOCS_REVIEW.md`.
4. **Inventario di baseline (FOUNDATION-01)** → `reports/BASELINE_INVENTORY.md`
   (framework/librerie, duplicazioni, decisioni storiche, vincoli, invarianti, gap di
   regressione, opportunità di modernizzazione).

## Esito AGENT-DOC-003 (sintesi)

- Inventario: unico context file attivo è `CLAUDE.md`; niente `AGENTS.md`/`.pi`/`.agents`;
  3 agenti Copilot in `.github/agents/` (Playwright) lasciati invariati.
- **Verificato** che per Pi, `AGENTS.md` sostituirebbe `CLAUDE.md` nella stessa directory
  (test empirico in `/tmp/pitest`): pertanto **non** è stato creato `AGENTS.md`.
- Corretti 4 punti di `CLAUDE.md`: schema DB (via `init_db`, non Alembic), State di
  AppContext, elenco route `_gui`, Data Model (aggiunti `Process`/`TrashEntry`, chiariti
  Materiali/Soluzioni).
- Preservate tutte le regole di sicurezza (DB dev, git stash, React loop, errori CORS,
  PDF schema versioning, NOMAD).
- **Nessuna skill creata** (conoscenza già coperta da `CLAUDE.md` + skill globali + piani).
- Limiti residui: Codex non legge `CLAUDE.md` (non risolto per non rompere Pi);
  `development.md` inesistente linkato da template (`CONTRIBUTING.md`/`README*`).

## Prossimi passi immediati

1. Far validare al maintainer la correzione della sezione schema DB in `CLAUDE.md`.
2. Eventuale migrazione ad `AGENTS.md` **solo** se Codex diventa un requisito (con cautela).
3. Riprendere le priorità tecniche di `TODO.md` (scientifiche/persistenza) previa
   autorizzazione esplicita.

**Nessun test eseguito** (suite con Docker/Postgres o `down -v` sul DB di sviluppo).
